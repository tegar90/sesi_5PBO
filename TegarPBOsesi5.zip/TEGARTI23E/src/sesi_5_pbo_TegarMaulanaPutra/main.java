/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesi_5_pbo_TegarMaulanaPutra;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class main {
     public static void main(String[]args){
        Mobil Mobil = new Mobil(4);
        Motor Motor = new Motor(true );
        
        Mobil.tampilkaninfo();
        Motor.tampilkaninfo();
        
     
       System.out.println("Service sedang dilakukan");
    
       
     
       Motor.servicekendaraan("  tune up  ");
          
     
    }
     
     
}
