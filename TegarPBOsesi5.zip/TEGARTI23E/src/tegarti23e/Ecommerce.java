/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

import java.util.Scanner;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class Ecommerce {
    public static void main (String[] args) {
        System.out.println("======CHOOSE YOUR BARANG=======");
        System.out.println("1. ELECTRONIC");
        System.out.println("2. CLOTH");
        System.out.println("3. FOOD");
        Scanner sc = new Scanner(System.in);
        String ulang = "Y";
        do{
            System.out.println("ISIKAN CODE BARANG :"); 
            int code = sc.nextInt();
            if(code==1){
                System.out.println("ISIKAN NAMA BARANG :");
                String name = sc.next();
                System.out.println("ISIKAN HARGA BARANG :");
                double price = sc.nextDouble();
                System.out.println("ISIKAN LAMA GARANSI :");
                int warranty = sc.nextInt();
                Electronic laptop = new Electronic(warranty, name, price);
                laptop.infoProduct();
            }else if(code==2){
                System.out.println("ISIKAN NAMA BARANG :");
                String name = sc.next();
                System.out.println("ISIKAN HARGA HARGA :");
                double price = sc.nextDouble();
                System.out.println("ISIKAN LAMA GARANSI :");
                int warranty = sc.nextInt();
                Electronic laptop = new Electronic(warranty, name, price);
                laptop.infoProduct();
            }
            System.out.println("APAKAH KAMU MAU BELANJA LAGI? Y/T");
            ulang = sc.next();
        }while(ulang.equals("Y"));
        
        Electronic laptop = new Electronic( 2,"HP",  1000020);
        Clothes calana = new Clothes("dickies belel", 20000, 40,"besi");
        Food sangu = new Food("date: 5/2/2030", "sangu", 50000);
        
        laptop.infoProduct();
        calana.infoProduct();
        sangu.infoProduct();
    }
    
}
