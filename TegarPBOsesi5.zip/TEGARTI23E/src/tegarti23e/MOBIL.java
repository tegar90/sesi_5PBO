/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tegarti23e;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class MOBIL {
    
    String Warna; 
    int Tahun;
    int Kecepatan;
    boolean status=false;
    
//mutator/ setter method    
public void setDataMobil(String c, int y, int Kecepatan){ 
    Warna = c;
    Tahun = y;
    this.Kecepatan = Kecepatan;
    }

//accessor/getter method
public String getWarna(){
    return Warna;
    }

public int getTahun(){
    return Tahun;
    }

public int getKecepatan(){
    return Kecepatan;
    }

public void tambahkecepatan(int k){
    if(status==true){
        Kecepatan += k;
           System.out.println("mobil sudah hidup");
    }
    else{
        System.out.println("mobil sudah mati");
    }
    }

public void hidupkanmobil(){
        status = true;
    }

public void matikanmobil(){
    status = false;
    }   

public void infoMobil(){
    System.out.println("Warna Mobil:" + getWarna());
    System.out.println("Tahun Pembuatan:" + getTahun());
    System.out.println("Kecepatan:" + getKecepatan());
    System.out.println("==================");
    }
}

