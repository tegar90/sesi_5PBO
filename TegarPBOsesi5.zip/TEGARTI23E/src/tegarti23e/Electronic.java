/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class Electronic extends Product{
    
    int warranty;

    public Electronic(int warranty, String name, double price) {
        super(name, price);
        this.warranty = warranty;
    }

    public int getWarranty() {
        return warranty;
    }

    public void setWarranty(int warranty) {
        this.warranty = warranty;
    }
    
    @Override
    public void infoProduct(){
        super.infoProduct();
        System.out.println("Warranty :" + getWarranty());
    }
}
