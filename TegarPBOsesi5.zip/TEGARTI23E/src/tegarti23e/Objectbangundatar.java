/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

import java.util.Scanner;

public class Objectbangundatar {
    
    public static void main(String[] args){
        System.out.println("-------------------------------------------------");
        System.out.println("1. bujur sangkar");
        System.out.println("2. segitiga");        
        System.out.println("3. persegi panjang");       
        System.out.println("-------------------------------------------------");     
        
        Scanner sc = new Scanner(System.in);
        System.out.println("masukan panjang");
        int pilihan = sc.nextInt();
        if (pilihan==1){
            System.out.println("isikan panjang");
            int panjang = sc.nextInt();
            System.out.println("isikan lebar");
            int lebar = sc.nextInt();
            
        if (pilihan==lebar){
            BujurSangkar bs = new BujurSangkar(panjang,lebar);
            int l = bs.getluas();
            int k = bs.getkeliling();
            bs.info();
        }else{
            System.out.println("panjang dan lebar harus sama");
        }
        }
    }
    
    
    
    
}
