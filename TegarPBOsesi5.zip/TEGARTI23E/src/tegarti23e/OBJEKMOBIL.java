/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class OBJEKMOBIL {
    public static void main(String[] args) {
        MOBIL mobilku = new MOBIL();
        MOBIL mobilmu = new MOBIL();
        
        mobilku.setDataMobil("merah", 2000, 0);
        mobilmu.setDataMobil("abu", 2003, 0);
        
        mobilku.hidupkanmobil();
        mobilmu.hidupkanmobil();
        
        mobilku.tambahkecepatan(0);
        mobilmu.tambahkecepatan(0);
        
        mobilku.infoMobil();
        mobilmu.infoMobil();
    }
}
