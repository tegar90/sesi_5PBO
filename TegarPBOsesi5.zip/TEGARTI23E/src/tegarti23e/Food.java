/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class Food extends Product{
    
    String expired;

    public Food(String expired, String name, double price) {
        super(name, price);
        this.expired = expired;
    }

    public String getExpired() {
        return expired;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    public void infoProduct(){
        super.infoProduct();
        System.out.println("size :" + getExpired());
    }
}
