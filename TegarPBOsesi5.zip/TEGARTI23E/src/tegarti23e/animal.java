/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class animal {
    String gender; //male or female
    String classified; //mamalia,reptil
    String name;
    
    
    public animal(){
        gender = "male";
        classified = "reptil";
    }
    
    public void setanimal(String gender, String classified, String name){
        this.gender = gender;
        this.classified = classified;
        this.name = name;
    }
    
    public String getgender(){
        return gender;
    }
  
    public String getclassified(){
        return classified;
    }
    public String getname(){
        return name;
    }    
    
    
}
    
