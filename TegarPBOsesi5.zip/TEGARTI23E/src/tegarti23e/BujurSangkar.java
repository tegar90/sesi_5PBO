package tegarti23e;

public class BujurSangkar extends BangunDatar {
    int luas;
    int keliling;
    
    public BujurSangkar(int panjang,int lebar){
        super(panjang, lebar);
        
    }
    
    public int getluas(){
        return super.getpanjang() * super.getlebar();
    }
    
    public int getkeliling(){
        return 4 * super.getpanjang();
    }
    
    public void info(){
        System.out.println("Luas Bujur Sangkar :" + getluas());
        System.out.println("keliling Bujur Sangkar :" + getkeliling());
        System.out.println("===================================================================================================================================================================================================================");
    }
}
