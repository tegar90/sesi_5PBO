
package tegarti23e;

public class BangunDatar {
    
    int panjang;
    int lebar;
    
    public BangunDatar(int panjang, int lebar){
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public void setBangunDatar(int panjang, int lebar){
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public int getpanjang(){
        return panjang;
    }
    
    public int getlebar(){
        return lebar;
    }
    
    
}
