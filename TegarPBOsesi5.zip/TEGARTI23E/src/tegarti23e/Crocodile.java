/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tegarti23e;

/**
 *
 * @author KOMPUTER JARKOM 21
 */
public class Crocodile extends animal {
    int age;
    public Crocodile(int age){
        super.name = "crocodile";
        this.age = age;
        super.classified = "reptile";
    }
    
    public void info(){
        System.out.println("my name is:" + super.name);
        System.out.println("classified ;" + super.classified);
        System.out.println("age :" + getage());
        
    }
    
    public void setage (int age){
        this.age = age;
    }
    
    public int getage(){
        return age;
    }
    
    
    
    
}
